#ifndef CARDS_H_INCLUDED
#define CARDS_H_INCLUDED

#include <string>
#include <sstream>
#include <iostream>

using namespace std;

const int MAX_HAND_SIZE = 5;

struct cardType{
    int  rank;
    char suit;
};

struct handType{
    cardType cards[MAX_HAND_SIZE];
    int      numCards;
};


int compare(cardType firstCard, cardType seconCard);
int compare(handType firstHand, handType secondHand);

string toString(int number);
string append1(string st1, string st2);
int charToInt(char cardRank);
string displayHand(handType hand);
string suitSpeller(char cardSuit);


#endif // CARDS_H_INCLUDED
