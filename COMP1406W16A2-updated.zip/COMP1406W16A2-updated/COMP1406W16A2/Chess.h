#ifndef CHESS_H_INCLUDED
#define CHESS_H_INCLUDED
#include <string>
#include <iostream>
#include <sstream>

using namespace std;

struct chessPiece{
   bool          isWhite;
   std::string   piece;
};

struct chessBoard{
   chessPiece square[8][8];
};

char toChar(int col);
string append(string st1, string st2);
short int toInt(char column);
string diagonalMvt(chessBoard board, short int col, short int row);
string lateralMvt(chessBoard board, short int col, short int row);
std::string validMoves(chessBoard board, char column, short int row);
std::string isOccupied (chessBoard board, int column, int row, chessPiece piece);
void chessDriver();

#endif // CHESS_H_INCLUDED
