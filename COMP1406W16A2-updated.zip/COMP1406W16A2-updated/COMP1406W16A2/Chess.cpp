//DO NOT RUN THIS CODE IT DOES NOT WORK FOR STRANGE REASONS I CAN'T FATHOM!!!
//DO NOT RUN THIS CODE IT DOES NOT WORK FOR STRANGE REASONS I CAN'T FATHOM!!!
//DO NOT RUN THIS CODE IT DOES NOT WORK FOR STRANGE REASONS I CAN'T FATHOM!!!
#include "Chess.h"
#include <string>
#include <iostream>
#include <sstream>

string append(string st1, string st2)//simple function to append strings since c++ wihtout proper libraries is a pain to use
{
    string stRet;
    stRet.append(st1);
    stRet.append(st2);
    return stRet;
}

string isOccupied (chessBoard board, int column, int row, chessPiece piece)//function to see if a square is taken by someone else
{
    stringstream returnValue;
    if (board.square[column][row].piece=="")//if the square has no name return that its a valid place to land
    {
        returnValue << column << row;
        return returnValue.str();
        returnValue.str(string());
    }
    else if (board.square[column][row].isWhite != piece.isWhite)//if it was not empty but is the opposite colour, you may land here
    {
        returnValue << column << row;
        return returnValue.str();
        returnValue.str(string());
    }
    else //otherwise do nothing
    {
        return "";
    }
    return "-1";
}

short int toInt(char column)//simple switch to convert the column char to a number so it may be used to search the array
{
    switch(column)
    {
        case 'a' : return 0;
        case 'b' : return 1;
        case 'c' : return 2;
        case 'd' : return 3;
        case 'e' : return 4;
        case 'f' : return 5;
        case 'g' : return 6;
        case 'h' : return 7;
        default : return -1;
    }
}

char toChar(int col)//simple switch to convert the int for the column back into a char for users convinience
{
    switch(col)
    {
        case 0 : return 'a';
        case 1 : return 'b';
        case 2 : return 'c';
        case 3 : return 'd';
        case 4 : return 'e';
        case 5 : return 'f';
        case 6 : return 'g';
        case 7 : return 'h';
        default : return -1;
    }
}

string diagonalMvt(chessBoard board, short int col, short int row)//function for diagonal movement (queen, bishop)
{
    stringstream RetValue;
    int i=1;
    bool passthrough = false;
    while (row+i<8 && col+i<8 && !passthrough)//if its within the bounds of the board and didnt pass through an enemy unit keep copying valid locations to land
    {
        if ((isOccupied(board, col+i, row+i, board.square[col][row]) != "*"))//if it is not taken by another unit keep retaining values and increment
        {
            RetValue << (isOccupied(board, col+i, row+i, board.square[col][row]));
            i++;
        }
        else
        {
            passthrough=true;//otherwise break the loop if a unit passed through another
        }
    }
    passthrough = false;
    i=1;
    while (row+i<8 && col-i<8 && !passthrough)
    {
        if ((isOccupied(board, col-i, row+i, board.square[col][row]) != "*"))
        {
            RetValue << (isOccupied(board, col-i, row+i, board.square[col][row]));
            i++;
        }
        else
        {
            passthrough=true;
        }
    }
    passthrough = false;
    i=1;
    while (row-i<8 && col+i<8 && !passthrough)
    {
        if ((isOccupied(board, col+i, row-i, board.square[col][row]) != "*"))
        {
            RetValue << (isOccupied(board, col+i, row-i, board.square[col][row]));
            i++;
        }
        else
        {
            passthrough=true;
        }
    }
    passthrough = false;
    i=1;
    while (row-i<8 && col-i<8 && !passthrough)
    {
        if ((isOccupied(board, col-i, row-i, board.square[col][row]) != "*"))
        {
            RetValue << (isOccupied(board, col-i, row-i, board.square[col][row]));
            i++;
        }
        else
        {
            passthrough=true;
        }
    }
    return RetValue.str();
}

string lateralMvt(chessBoard board, short int col, short int row)
{
    stringstream RetValue;
    int i=1;
    bool passthrough = false;
    while (col+i<8 && !passthrough)
    {
        if ((isOccupied(board, col+i, row, board.square[col][row]) != "*"))
        {
            RetValue << (isOccupied(board, col+i, row, board.square[col][row]));
            i++;
        }
        else
        {
            passthrough=true;
        }
    }
    i = 1;
    passthrough = false;
    while (col-i<8 && !passthrough)
    {
        if ((isOccupied(board, col-i, row, board.square[col][row]) != "*"))
        {
            RetValue << (isOccupied(board, col-i, row, board.square[col][row]));
            i++;
        }
        else
        {
            passthrough=true;
        }
    }
    i = 1;
    passthrough = false;
    while (row+i<8 && !passthrough)
    {
        if ((isOccupied(board, col, row+i, board.square[col][row]) != "*"))
        {
            RetValue << (isOccupied(board, i, row, board.square[col][row]));
            i++;
        }
        else
        {
            passthrough=true;
        }
    }
    i = 1;
    passthrough = false;
    while (row-i<8 && !passthrough)
    {
        if ((isOccupied(board, col, row-i, board.square[col][row]) != "*"))
        {
            RetValue << (isOccupied(board, col, row-i, board.square[col][row]));
            i++;
        }
        else
        {
            passthrough=true;
        }
    }
    return RetValue.str();
}

string validMoves(chessBoard board, char column, short int row)
{
    stringstream answer;

    short int col = 0;
    col = toInt(column);
    row--;
    if (board.square[row][col].piece == "Queen")//match strings to see which kind of unit it is then simulate all possible movements
    {
        answer << diagonalMvt(board, col, row);
        answer << lateralMvt(board, col, row);
    }
    else if (board.square[row][col].piece == "King")//match strings to see which kind of unit it is then simulate all possible movements
    {
        answer << isOccupied(board, col+1, row, board.square[col][row]);
        answer << isOccupied(board, col-1, row, board.square[col][row]);
        answer << isOccupied(board, col, row+1, board.square[col][row]);
        answer << isOccupied(board, col, row-1, board.square[col][row]);
        answer << isOccupied(board, col+1, row+1, board.square[col][row]);
        answer << isOccupied(board, col-1, row-1, board.square[col][row]);
        answer << isOccupied(board, col-1, row+1, board.square[col][row]);
        answer << isOccupied(board, col+1, row-1, board.square[col][row]);
    }
    else if (board.square[row][col].piece == "Bichop")//match strings to see which kind of unit it is then simulate all possible movements
    {
        answer << diagonalMvt(board, col, row);
    }
    else if (board.square[row][col].piece == "Rook")//match strings to see which kind of unit it is then simulate all possible movements
    {
        answer << lateralMvt(board, col, row);
    }
    else if (board.square[row][col].piece == "Knight")//match strings to see which kind of unit it is then simulate all possible movements
    {
        answer << isOccupied(board, col+1, row+3, board.square[col][row]);
        answer << isOccupied(board, col-1, row+3, board.square[col][row]);
        answer << isOccupied(board, col+3, row+1, board.square[col][row]);
        answer << isOccupied(board, col+3, row-1, board.square[col][row]);
        answer << isOccupied(board, col+1, row-3, board.square[col][row]);
        answer << isOccupied(board, col-1, row-3, board.square[col][row]);
        answer << isOccupied(board, col-3, row+1, board.square[col][row]);
        answer << isOccupied(board, col-3, row-1, board.square[col][row]);
    }
    else if (board.square[row][col].piece == "Pawn")//match strings to see which kind of unit it is then simulate all possible movements
    {
        if (board.square[row][col].isWhite)
        {
            answer << isOccupied(board, col+1, row, board.square[col][row]);
        }
        else
        {
            answer << isOccupied(board, col-1, row, board.square[col][row]);
        }
    }
    else//if the square is empty there are no units there
    {
        return "No unit here...";
    }
    return answer.str();
}

void chessDriver(){

    chessBoard board;

    for(int row=0; row<8; row++){
        for(int col=0; col<8; col++){
            board.square[row][col].piece = "";
        }
    }

    board.square[7][0].piece = "Rook";
    board.square[7][0].isWhite = false;

    board.square[7][1].piece = "Knight";
    board.square[7][1].isWhite = false;

    board.square[7][2].piece = "Bishop";
    board.square[7][2].isWhite = false;

    board.square[7][3].piece = "Queen";
    board.square[7][3].isWhite = false;

    board.square[7][4].piece = "King";
    board.square[7][4].isWhite = false;

    board.square[7][5].piece = "Bishop";
    board.square[7][5].isWhite = false;

    board.square[7][6].piece = "Knight";
    board.square[7][6].isWhite = false;

    board.square[7][7].piece = "Rook";
    board.square[7][7].isWhite = false;

    for(int col = 0; col<8; col++){
        board.square[6][col].piece = "Pawn";
        board.square[6][col].isWhite = false;
    }
    board.square[6][3].piece = "";       // remove the pawn in d7
    board.square[6][6].isWhite = true;   // pawn in g7 is white

    board.square[5][5].piece = "Queen";
    board.square[5][5].isWhite = true;


    std::cout << validMoves(board, 'f', 6) << std::endl;
    std::cout << validMoves(board, 'd', 2) << std::endl;
    std::cout << validMoves(board, 'a', 8) << std::endl;
    std::cout << validMoves(board, 'f', 8) << std::endl;
}
