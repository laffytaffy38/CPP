#ifndef STATS_CPP_INCLUDED
#define STATS_CPP_INCLUDED

#include "Stats.h"

double trimmedMean(int data[], int dataSize, int outliers)
{
    double SumOfData = 0;
    int i = outliers, j = 0;
    while(i>=(outliers-1) && i<=(dataSize-outliers-1))//sum of the data array without the outliers
    {
        SumOfData += data[i];//where the magic happens
        j++;//number of times summing integers together to get the average in the end
        i++;//incrementation through array
    }
    return SumOfData/j;//self explanatory
}


#endif // STATS_CPP_INCLUDED
