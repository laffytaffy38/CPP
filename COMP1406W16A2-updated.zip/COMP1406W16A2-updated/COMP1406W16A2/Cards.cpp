#include "Cards.h"

using namespace std;

int charToInt(char cardRank)//simple function to rank cards based on suits (applicable for bridge)
{
    if (cardRank == 'c')
    {
       return 1;
    }
    else if (cardRank == 'd')
    {
        return 2;
    }
    else if (cardRank == 'h')
    {
        return 3;
    }
    else if (cardRank == 's')
    {
        return 4;
    }
    else
    {
        return -1;
    }
}

int compare(cardType c1, cardType c2)//compare 2 cardtypes against each other
{
    int diff, r1, r2 = 0;
    diff = (c1.rank-c2.rank);
    if (diff == 0)
    {
        r1 = charToInt(c1.suit);
        r2 = charToInt(c2.suit);
        if (r1>r2)
        {
            return 1;
        }
        else if (r1 == r2)
        {
            return 0;
        }
        else
        {
            return -1;
        }
    }
    else
    {
    return diff;//return the difference if its negative c1 is smaller than c2
    }
}

int compare(handType firstHand, handType secondHand)//compare complete hand sets against one another
{
    cardType highestCard1, highestCard2;
    highestCard1.suit = 'c';
    highestCard1.rank = 2;
    highestCard2.suit = 'c';
    highestCard2.rank = 2;
    int diff = 0;

    for (int i = 0; i < firstHand.numCards; i++)//go through the cards in hand one
    {
        diff = compare(firstHand.cards[i], highestCard1);//compare each card in yout hand to find the highest card
        if (diff>0)
        {
            highestCard1.rank = firstHand.cards[i].rank;
            highestCard1.suit = firstHand.cards[i].suit;
        }
    }

    for (int i = 0; i < secondHand.numCards; i++)//same as the first
    {
        diff = compare(secondHand.cards[i], highestCard2);//ditto
        if (diff>0)
        {
            highestCard2.rank = secondHand.cards[i].rank;
            highestCard2.suit = secondHand.cards[i].suit;
        }
    }

    diff = compare(highestCard1, highestCard2);//compare the highest card from each hand to see which hand has the highest card
    if (diff>0)
    {
        return 1;
    }
    else if (diff == 0)
    {
        return 0;
    }
    else if (diff>0)
    {
        return -1;
    }
}

string append1(string st1, string st2)//simple function to append 2 strings together
{
    string stRet;
    stRet.append(st1);
    stRet.append(st2);
    return stRet;
}

string toString(int number)//converts an integer to a string
{
    string returningString;
    ostringstream convHold;
    convHold << number;
    return convHold.str();
}

string displayHand(handType hand)//displays the cards in a hand
{
    string cAnswer;
    for (int i = 0; i < hand.numCards; i++)
    {
        if (hand.cards[i].rank <= 10)
        {
            string rankOf (append1(toString(hand.cards[i].rank), " of "));
            string suit (suitSpeller(hand.cards[i].suit));
            string result (append1(rankOf, suit));
            cAnswer = append1(result, cAnswer);
            cAnswer = append1(cAnswer, "\n");
        }
        else if (hand.cards[i].rank == 11)
        {
            string rankOf ( "Jack of ");
            string suit (suitSpeller(hand.cards[i].suit));
            string result (append1(rankOf, suit));
            cAnswer = append1(result, cAnswer);
            cAnswer = append1(cAnswer, "\n");
        }
        else if (hand.cards[i].rank == 12)
        {
            string rankOf ("Queen of ");
            string suit (suitSpeller(hand.cards[i].suit));
            string result (append1(rankOf, suit));
            cAnswer = append1(result, cAnswer);
            cAnswer = append1(cAnswer, "\n");
        }
        else if (hand.cards[i].rank == 13)
        {
            string rankOf ("King of ");
            string suit (suitSpeller(hand.cards[i].suit));
            string result (append1(rankOf, suit));
            cAnswer = append1(result, cAnswer);
            cAnswer = append1(cAnswer, "\n");
        }
        else if (hand.cards[i].rank == 14)
        {
            string rankOf ("Ace of ");
            string suit (suitSpeller(hand.cards[i].suit));
            string result (append1(rankOf, suit));
            cAnswer = append1(result, cAnswer);
            cAnswer = append1(cAnswer, "\n");
        }
        else
        {
            return "-1\n";
        }
    }
    return cAnswer;
}
string suitSpeller(char cardSuit)//simple function to spell out the character representing a suit
{
    if (cardSuit == 'c')
    {
        return "clubs\n";
    }
    else if (cardSuit == 'h')
    {
        return "hearts\n";
    }
    else if (cardSuit == 'd')
    {
        return"diamonds\n";
    }
    else if (cardSuit == 's')
    {
        return "spades\n";
    }
    else
    {
        return "-1\n";
    }
}
