#ifndef STATS_H_INCLUDED
#define STATS_H_INCLUDED


double trimmedMean(int data[], int dataSize, int outliers);



#endif // STATS_H_INCLUDED
